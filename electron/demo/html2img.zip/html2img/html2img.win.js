﻿/******************************************************************************/
'use strict';
/******************************************************************************/
const fs = require('fs');
const path = require('path');
const rl = require('readline');
const { app, BrowserWindow } = require('electron');
/******************************************************************************/
const cfgPath = path.join(__dirname, 'html2img.cfg.json');
const imgPath = path.join(__dirname, 'img');
const urls = [];
const timeoutFromLoad = 100;
const timeoutFromResize = 100;

let   cfg;
let   mainWindow;
let   i = 0;
/******************************************************************************/
app.disableHardwareAcceleration();
if (!fs.readdirSync(__dirname).includes('img')) fs.mkdirSync(imgPath);
app.once('ready', createWindow);
/******************************************************************************/
function createWindow() {
  mainWindow = new BrowserWindow({
    show: false,
    enableLargerThanScreen: true,
    webPreferences: {
      nodeIntegration: false,
    },
  });
  mainWindow.setMenu(null);
  restoreCfg();
  mainWindow.show();
  mainWindow.once('close', saveCfg);
  mainWindow.webContents.on('did-finish-load', () => {
    setTimeout(saveDoc, timeoutFromLoad);
  });
  getURLs();
}
/******************************************************************************/
function restoreCfg() {
  cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8').replace(/^\uFEFF/, ''));
  mainWindow.setBounds(cfg.bounds);
}
/******************************************************************************/
function saveCfg() {
  cfg.bounds = mainWindow.getBounds();
  fs.writeFileSync(cfgPath, `\uFEFF${JSON.stringify(cfg, null, '  ')}\n`, 'utf8');
}
/******************************************************************************/
function getURLs() {
  let lineNumber = 0;

  rl.createInterface({
    input: fs.createReadStream(
      path.join(__dirname, 'html2img.urls.txt'), { encoding: 'utf8' }
    ),
  }).on('line', line => {
    if (++lineNumber === 1) line = line.replace(/^\uFEFF/, '');
    line = line.trim();
    if (line) urls.push(line);
  }).on('close', getDoc);
}
/******************************************************************************/
function getDoc() {
  if (urls.length) mainWindow.loadURL(urls.shift());
  else console.log('All done.');
}
/******************************************************************************/
function saveDoc() {
  mainWindow.webContents.executeJavaScript(
    `[document.documentElement.scrollWidth, document.documentElement.scrollHeight]`,
    false, result => {
      mainWindow.setContentSize(result[0], result[1]);
      setTimeout(() => {
        mainWindow.webContents.capturePage(img => {
          fs.writeFileSync(path.join(imgPath, `${++i}.png`), img.toPNG());
          console.log(`${mainWindow.webContents.getURL()} saved.`);
          getDoc();
        });
      }, timeoutFromResize);
    }
  );
}
/******************************************************************************/
