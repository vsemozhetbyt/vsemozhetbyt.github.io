﻿/******************************************************************************/
'use strict';
/******************************************************************************/
const fs = require('fs');
const path = require('path');
const rl = require('readline');
const { app, BrowserWindow } = require('electron');
/******************************************************************************/
const cfgPath = path.join(__dirname, 'html2file.cfg.json');
const filesPath = path.join(__dirname, 'files');
const urls = [];

let   cfg;
let   mainWindow;
let   i = 0;
/******************************************************************************/
if (!fs.readdirSync(__dirname).includes('files')) fs.mkdirSync(filesPath);
app.once('ready', createWindow);
/******************************************************************************/
function createWindow() {
  mainWindow = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
    },
  });
  mainWindow.setMenu(null);
  restoreCfg();
  mainWindow.show();
  mainWindow.once('close', saveCfg);
  mainWindow.webContents.on('did-finish-load', saveDoc);
  getURLs();
}
/******************************************************************************/
function restoreCfg() {
  cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8').replace(/^\uFEFF/, ''));
  mainWindow.setBounds(cfg.bounds);
}
/******************************************************************************/
function saveCfg() {
  cfg.bounds = mainWindow.getBounds();
  fs.writeFileSync(cfgPath, `\uFEFF${JSON.stringify(cfg, null, '  ')}\n`, 'utf8');
}
/******************************************************************************/
function getURLs() {
  let lineNumber = 0;

  rl.createInterface({
    input: fs.createReadStream(
      path.join(__dirname, 'html2file.urls.txt'), { encoding: 'utf8' }
    ),
  }).on('line', line => {
    if (++lineNumber === 1) line = line.replace(/^\uFEFF/, '');
    line = line.trim();
    if (line) urls.push(line);
  }).on('close', getDoc);
}
/******************************************************************************/
function getDoc() {
  if (urls.length) mainWindow.loadURL(urls.shift());
  else console.log('All done.');
}
/******************************************************************************/
function saveDoc() {
  mainWindow.webContents.savePage(
    path.join(filesPath, `${++i}.html`),
    'HTMLComplete',
    error => {
      if (error) {
        console.error(error);
        return;
      }
      console.log(`${mainWindow.webContents.getURL()} saved.`);
      getDoc();
    }
  );
}
/******************************************************************************/
