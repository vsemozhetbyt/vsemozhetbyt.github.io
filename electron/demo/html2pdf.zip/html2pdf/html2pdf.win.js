﻿/******************************************************************************/
'use strict';
/******************************************************************************/
const fs = require('fs');
const path = require('path');
const rl = require('readline');
const { app, BrowserWindow } = require('electron');
/******************************************************************************/
const cfgPath = path.join(__dirname, 'html2pdf.cfg.json');
const pdfPath = path.join(__dirname, 'pdf');
const urls = [];

let   cfg;
let   mainWindow;
let   i = 0;
/******************************************************************************/
if (!fs.readdirSync(__dirname).includes('pdf')) fs.mkdirSync(pdfPath);
app.once('ready', createWindow);
/******************************************************************************/
function createWindow() {
  mainWindow = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
    },
  });
  mainWindow.setMenu(null);
  restoreCfg();
  mainWindow.show();
  mainWindow.once('close', saveCfg);
  mainWindow.webContents.on('did-finish-load', saveDoc);
  getURLs();
}
/******************************************************************************/
function restoreCfg() {
  cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8').replace(/^\uFEFF/, ''));
  mainWindow.setBounds(cfg.bounds);
}
/******************************************************************************/
function saveCfg() {
  cfg.bounds = mainWindow.getBounds();
  fs.writeFileSync(cfgPath, `\uFEFF${JSON.stringify(cfg, null, '  ')}\n`, 'utf8');
}
/******************************************************************************/
function getURLs() {
  let lineNumber = 0;

  rl.createInterface({
    input: fs.createReadStream(
      path.join(__dirname, 'html2pdf.urls.txt'), { encoding: 'utf8' }
    ),
  }).on('line', line => {
    if (++lineNumber === 1) line = line.replace(/^\uFEFF/, '');
    line = line.trim();
    if (line) urls.push(line);
  }).on('close', getDoc);
}
/******************************************************************************/
function getDoc() {
  if (urls.length) mainWindow.loadURL(urls.shift());
  else console.log('All done.');
}
/******************************************************************************/
function saveDoc() {
  mainWindow.webContents.printToPDF(
    {
      marginsType: 0,
      pageSize: 'A4',
      printBackground: false,
      printSelectionOnly: false,
      landscape: false,
    },
    (error, PDFBuffer) => {
      if (error) {
        console.error(error);
        return;
      }
      fs.writeFileSync(path.join(pdfPath, `${++i}.pdf`), PDFBuffer);
      console.log(`${mainWindow.webContents.getURL()} saved.`);
      getDoc();
    }
  );
}
/******************************************************************************/
